
print("Operaciones Aritmeticas")

num1 = int(input("ingrese primer numero: "))
num2 = int(input("ingrese segundo numero: "))

def menu():

    print("Menu")

